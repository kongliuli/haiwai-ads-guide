# Changelog

## 4.11.1.0
* Certified with Moloco SDK 4.11.1.

## 4.11.0.0
* Certified with Moloco SDK 4.11.0.

## 4.10.0.1
* Fixed adapter versioning for SPM

## 4.10.0.0
* Certified with Moloco SDK 4.10.0.

## 4.9.1.0
* Certified with Moloco SDK 4.9.1.

## 4.9.0.0
* Certified with Moloco SDK 4.9.0.

## 4.8.1.0
* Certified with Moloco SDK 4.8.1.

## 4.8.0.0
* Certified with Moloco SDK 4.8.0.

## 4.7.0.0
* Certified with Moloco SDK 4.7.0.

## 4.6.1.1
* Updated `preparingViewsForInteraction` mediation logging to pass an empty views array for Moloco native ads to avoid crashes.

## 4.6.1.0
* Certified with Moloco SDK 4.6.1.

## 4.6.0.0
* Certified with Moloco SDK 4.6.0.

## 4.5.1.0
* Certified with Moloco SDK 4.5.1.

## 4.5.0.0
* Certified with Moloco SDK 4.5.0.

## 4.4.1.0
* Certified with Moloco SDK 4.4.1.

## 4.4.0.0
* Certified with Moloco SDK 4.4.0.

## 4.3.0.0
* Certified with Moloco SDK 4.3.0.

## 4.2.0.0
* Certified with Moloco SDK 4.2.0.

## 4.1.2.0
* Certified with Moloco SDK 4.1.2.

## 4.1.1.0
* Certified with Moloco SDK 4.1.1.
* Removed outdated simulator architecture exclusion from podspec.

## 4.1.0.0
* Certified with Moloco SDK 4.1.0.

## 4.0.0.0
* Certified with Moloco SDK 4.0.0.

## 3.13.0.0
* Certified with Moloco SDK 3.13.0.

## 3.12.1.0
* Certified with Moloco SDK 3.12.1.
* Distributed as a static framework within the XCFramework.

## 3.12.0.0
* Certified with Moloco SDK 3.12.0.

## 3.11.0.0
* Certified with Moloco SDK 3.11.0.

## 3.10.1.0
* Certified with Moloco SDK 3.10.1.
* Update ad display failed error code.

## 3.10.0.0
* Certified with Moloco SDK 3.10.0.

## 3.9.1.1
* Removed requirement of the title asset for native banners and MRECs.

## 3.9.1.0
* Certified with Moloco SDK 3.9.1.

## 3.9.0.0
* Certified with Moloco SDK 3.9.0.
* Updated minimum Xcode requirement to 16.0.

## 3.8.0.2
* Replaced availability checks with `ALUtils.isInclusiveVersion(_:forMinVersion:maxVersion:)` to suppress version warnings.

## 3.8.0.1
* Added a guard to only allow signal collection starting from minimum iOS 13.

## 3.8.0.0
* Certified with Moloco SDK 3.8.0.

## 3.7.2.0
* Certified with Moloco SDK 3.7.2.

## 3.7.1.0
* Certified with Moloco SDK 3.7.1.

## 3.7.0.0
* Certified with Moloco SDK 3.7.0.

## 3.6.0.1
* Updated minimum iOS version to iOS 12.0.

## 3.6.0.0
* Certified with Moloco SDK 3.6.0.
* Added support for native and native ad view ads.
* Updated minimum iOS version to iOS 13.0.

## 3.4.0.0
* Certified with Moloco SDK 3.4.0.
* Removed redundant log output when initialization was already completed.

## 3.3.1.0
* Certified with Moloco SDK 3.3.1.

## 3.3.0.0
* Certified with Moloco SDK 3.3.0.

## 3.2.0.0
* Certified with Moloco SDK 3.2.0.

## 3.1.3.1
* Requires minimum AppLovin MAX SDK version be 13.0.0.
* Removed COPPA support.

## 3.1.3.0
* Certified with Moloco SDK 3.1.3.

## 3.1.2.0
* Certified with Moloco SDK 3.1.2.

## 3.1.1.0
* Certified with Moloco SDK 3.1.1.

## 3.0.0.1
* Updated minimum iOS version to iOS 12.0.

## 3.0.0.0
* Certified with Moloco SDK 3.0.0.

## 2.2.1.0
* Certified with Moloco SDK 2.2.1.
* Updated minimum Xcode requirement to 15.0.

## 2.1.1.1
* Add support for leaders.

## 2.1.1.0
* Initial commit.
* Minimum AppLovin MAX SDK version 12.3.0.
