//
//  ALInMobiMediationAdapter.m
//  AppLovinSDK
//
//  Created by Thomas So on 2/9/19.
//  Copyright © 2022 AppLovin Corporation. All rights reserved.
//

#import "ALInMobiMediationAdapter.h"
#import <InMobiSDK/InMobiSDK.h>

#define ADAPTER_VERSION @"11.5.0.0"

#define TITLE_LABEL_TAG          1
#define MEDIA_VIEW_CONTAINER_TAG 2
#define ICON_VIEW_TAG            3
#define BODY_VIEW_TAG            4
#define CALL_TO_ACTION_VIEW_TAG  5
#define RATING_VIEW_TAG          6
#define ADVERTISER_VIEW_TAG      8

/**
 * Dedicated delegate object for InMobi AdView ads.
 */
@interface ALInMobiMediationAdapterAdViewDelegate : NSObject <IMBannerDelegate>

@property (nonatomic,   weak) ALInMobiMediationAdapter *parentAdapter;
@property (nonatomic, strong) id<MAAdViewAdapterDelegate> delegate;
@property (nonatomic, assign) CGSize adSize;

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                               adSize:(CGSize)adSize
                            andNotify:(id<MAAdViewAdapterDelegate>)delegate;
- (instancetype)init NS_UNAVAILABLE;

@end

/**
 * Dedicated delegate object for InMobi interstitial ads.
 */
@interface ALInMobiMediationAdapterInterstitialAdDelegate : NSObject <IMInterstitialDelegate>

@property (nonatomic,   weak) ALInMobiMediationAdapter *parentAdapter;
@property (nonatomic, strong) id<MAInterstitialAdapterDelegate> delegate;

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter andNotify:(id<MAInterstitialAdapterDelegate>)delegate;
- (instancetype)init NS_UNAVAILABLE;

@end

/**
 * Dedicated delegate object for InMobi rewarded ads.
 */
@interface ALInMobiMediationAdapterRewardedAdDelegate : NSObject <IMInterstitialDelegate>

@property (nonatomic,   weak) ALInMobiMediationAdapter *parentAdapter;
@property (nonatomic, strong) id<MARewardedAdapterDelegate> delegate;
@property (nonatomic, assign, getter=hasGrantedReward) BOOL grantedReward;

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter andNotify:(id<MARewardedAdapterDelegate>)delegate;
- (instancetype)init NS_UNAVAILABLE;

@end

/**
 * Dedicated delegate object for InMobi native AdView ads.
 */
@interface ALInMobiMediationAdapterNativeAdViewDelegate : NSObject <IMNativeDelegate>

@property (nonatomic,   weak) ALInMobiMediationAdapter *parentAdapter;
@property (nonatomic,   weak) MAAdFormat *format;
@property (nonatomic, strong) NSDictionary<NSString *, id> *serverParameters;
@property (nonatomic, strong) id<MAAdViewAdapterDelegate> delegate;
@property (nonatomic,   copy) NSString *placementId;

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                               format:(MAAdFormat *)format
                           parameters:(id<MAAdapterResponseParameters>)parameters
                            andNotify:(id<MAAdViewAdapterDelegate>)delegate;
- (instancetype)init NS_UNAVAILABLE;

@end

/**
 * Dedicated delegate object for InMobi native ads.
 */
@interface ALInMobiMediationAdapterNativeAdDelegate : NSObject <IMNativeDelegate>

@property (nonatomic,   weak) ALInMobiMediationAdapter *parentAdapter;
@property (nonatomic, strong) id<MANativeAdAdapterDelegate> delegate;
@property (nonatomic, strong) NSDictionary<NSString *, id> *serverParameters;
@property (nonatomic, strong) NSString *placementId;

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter parameters:(id<MAAdapterResponseParameters>)parameters andNotify:(id<MANativeAdAdapterDelegate>)delegate;
- (instancetype)init NS_UNAVAILABLE;

@end

@interface MAInMobiNativeAd : MANativeAd
@property (nonatomic, weak) ALInMobiMediationAdapter *parentAdapter;
@property (nonatomic, weak) MAAdFormat *adFormat;
- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                             adFormat:(MAAdFormat *)format
                         builderBlock:(NS_NOESCAPE MANativeAdBuilderBlock)builderBlock;
- (instancetype)initWithFormat:(MAAdFormat *)format builderBlock:(NS_NOESCAPE MANativeAdBuilderBlock)builderBlock NS_UNAVAILABLE;
@end

@interface ALInMobiMediationAdapter ()

// AdView
@property (nonatomic, strong) IMBanner *adView;
@property (nonatomic, strong) ALInMobiMediationAdapterAdViewDelegate *adViewDelegate;

// Interstitial
@property (nonatomic, strong) IMInterstitial *interstitialAd;
@property (nonatomic, strong) ALInMobiMediationAdapterInterstitialAdDelegate *interstitialAdDelegate;

// Rewarded
@property (nonatomic, strong) IMInterstitial *rewardedAd;
@property (nonatomic, strong) ALInMobiMediationAdapterRewardedAdDelegate *rewardedAdDelegate;

// Native
@property (nonatomic, strong) IMNative *nativeAd;
@property (nonatomic, strong) ALInMobiMediationAdapterNativeAdDelegate *nativeAdDelegate;

// Native AdView
@property (nonatomic, strong) MANativeAd *maxNativeAdViewAd;
@property (nonatomic, strong) ALInMobiMediationAdapterNativeAdViewDelegate *nativeAdViewDelegate;

@end

@implementation ALInMobiMediationAdapter
static ALAtomicBoolean              *ALInMobiInitialized;
static MAAdapterInitializationStatus ALInMobiInitializationStatus = NSIntegerMin;

// String constants
static NSString *const ADAPTIVE_BANNER = @"adaptive_banner";
static NSString *const AB_AD_SLOT = @"ab-ad-slot";
static NSString *const AB_TYPE = @"ab-type";
static NSString *const ADAPTIVE_TYPE_INLINE = @"inline";
static NSString *const ADAPTIVE_TYPE_ANCHORED = @"anchored";

+ (void)initialize
{
    [super initialize];
    ALInMobiInitialized = [[ALAtomicBoolean alloc] init];
}

#pragma mark - MAAdapter Methods

- (NSString *)SDKVersion
{
    return [IMSdk getVersion];
}

- (NSString *)adapterVersion
{
    return ADAPTER_VERSION;
}

- (void)initializeWithParameters:(id<MAAdapterInitializationParameters>)parameters completionHandler:(void (^)(MAAdapterInitializationStatus, NSString *_Nullable))completionHandler
{
    if ( [ALInMobiInitialized compareAndSet: NO update: YES] )
    {
        NSString *accountID = [parameters.serverParameters al_stringForKey: @"account_id"];
        [self log: @"Initializing InMobi SDK with account id: %@...", accountID];
        
        // API docs - "Debug mode is only for simulators, wont work on actual devices"
        [IMUnifiedIdService enableDebugMode: [ALUtils isSimulator] && [parameters isTesting]];
        
        ALInMobiInitializationStatus = MAAdapterInitializationStatusInitializing;
        
        NSDictionary<NSString *, id> *consentDict = [self consentDictionaryForParameters: parameters];
        [IMSdk initWithAccountID: accountID consentDictionary: consentDict andCompletionHandler:^(NSError *_Nullable error) {
            if ( error )
            {
                [self log: @"InMobi SDK initialization failed with error: %@", error];
                
                ALInMobiInitializationStatus = MAAdapterInitializationStatusInitializedFailure;
                completionHandler(ALInMobiInitializationStatus, error.description);
            }
            else
            {
                [self log: @"InMobi SDK successfully initialized"];
                
                ALInMobiInitializationStatus = MAAdapterInitializationStatusInitializedSuccess;
                completionHandler(ALInMobiInitializationStatus, nil);
            }
        }];
        
        IMSDKLogLevel logLevel = [parameters isTesting] ? IMSDKLogLevelDebug : IMSDKLogLevelError;
        [IMSdk setLogLevel: logLevel];
    }
    else
    {
        completionHandler(ALInMobiInitializationStatus, nil);
    }
}

- (void)destroy
{
    self.adView.delegate = nil;
    self.adViewDelegate.delegate = nil;
    self.adViewDelegate = nil;
    
    self.interstitialAd.delegate = nil;
    self.interstitialAd = nil;
    self.interstitialAdDelegate.delegate = nil;
    self.interstitialAdDelegate = nil;
    
    self.rewardedAd.delegate = nil;
    self.rewardedAd = nil;
    self.rewardedAdDelegate.delegate = nil;
    self.rewardedAdDelegate = nil;
    
    self.nativeAd.delegate = nil;
    self.nativeAd = nil;
    self.nativeAdDelegate.delegate = nil;
    self.nativeAdDelegate = nil;
    
    self.maxNativeAdViewAd = nil;
    self.nativeAdViewDelegate.delegate = nil;
    self.nativeAdViewDelegate = nil;
}

#pragma mark - Signal Collection

- (void)collectSignalWithParameters:(id<MASignalCollectionParameters>)parameters andNotify:(id<MASignalCollectionDelegate>)delegate
{
    [self log: @"Collecting signal..."];
    
    if ( MAAdapterInitializationStatusInitializedFailure == ALInMobiInitializationStatus )
    {
        [delegate didFailToCollectSignalWithErrorMessage: @"InMobi SDK initialization failed."];
        return;
    }
    
    [self updatePrivacySettingsWithParameters: parameters];
    
    BOOL isAdaptiveAdViewEnabled = [parameters.localExtraParameters al_boolForKey: ADAPTIVE_BANNER defaultValue: NO];
    NSString *signal = [IMSdk getTokenWithExtras: [self extrasForParameters: parameters adFormat: parameters.adFormat isAdaptiveAdViewEnabled: isAdaptiveAdViewEnabled] andKeywords: nil];
    [delegate didCollectSignal: signal];
}

#pragma mark - AdView Adapter

- (void)loadAdViewAdForParameters:(id<MAAdapterResponseParameters>)parameters adFormat:(MAAdFormat *)adFormat andNotify:(id<MAAdViewAdapterDelegate>)delegate
{
    long long placementId = parameters.thirdPartyAdPlacementIdentifier.longLongValue;
    BOOL isNative = [parameters.serverParameters al_boolForKey: @"is_native"];
    [self log: @"Loading%@%@ AdView ad for placement: %lld...", isNative ? @" native " : @" ", adFormat.label, placementId];
    
    [self updatePrivacySettingsWithParameters: parameters];
    
    NSString *bidResponse = parameters.bidResponse;
    BOOL isBiddingAd = [parameters.bidResponse al_isValidString];
    
    if ( isNative )
    {
        self.nativeAdViewDelegate = [[ALInMobiMediationAdapterNativeAdViewDelegate alloc] initWithParentAdapter: self
                                                                                                         format: adFormat
                                                                                                     parameters: parameters
                                                                                                      andNotify: delegate];
        self.nativeAd = [[IMNative alloc] initWithPlacementId: placementId delegate: self.nativeAdViewDelegate];
        self.nativeAd.extras = [self baseExtras];
        
        if ( isBiddingAd )
        {
            [self.nativeAd load: [bidResponse dataUsingEncoding: NSUTF8StringEncoding]];
        }
        else
        {
            [self.nativeAd load];
        }
    }
    else
    {
        BOOL isAdaptiveBannerEnabled = [parameters.serverParameters al_boolForKey: ADAPTIVE_BANNER defaultValue: NO];
        if ( isAdaptiveBannerEnabled && ALSdk.versionCode < 13020099 )
        {
            isAdaptiveBannerEnabled = NO;
            [self userError: @"Please update AppLovin MAX SDK to version 13.2.0 or higher in order to use InMobi adaptive ads"];
        }
        
        // InMobi expects the standard banner size in the layout request and reads adaptive
        // dimensions from extras (ab-ad-slot / ab-type).
        CGRect frame = [self rectFromAdFormat: adFormat];
        CGSize reportedAdSize = frame.size;
        if ( isAdaptiveBannerEnabled && [self isAdaptiveAdViewFormat: adFormat forParameters: parameters] )
        {
            reportedAdSize = [self adaptiveAdSizeFromParameters: parameters];
        }
        
        self.adView = [[IMBanner alloc] initWithFrame: frame placementId: placementId];
        self.adView.extras = [self extrasForParameters: parameters adFormat: adFormat isAdaptiveAdViewEnabled: isAdaptiveBannerEnabled];
        self.adView.transitionAnimation = UIViewAnimationTransitionNone;
        [self.adView shouldAutoRefresh: NO];
        
        self.adViewDelegate = [[ALInMobiMediationAdapterAdViewDelegate alloc] initWithParentAdapter: self
                                                                                             adSize: reportedAdSize
                                                                                          andNotify: delegate];
        self.adView.delegate = self.adViewDelegate;
        
        if ( isBiddingAd )
        {
            [self.adView load: [bidResponse dataUsingEncoding: NSUTF8StringEncoding]];
        }
        else
        {
            [self.adView load];
        }
    }
}

#pragma mark - Interstitial Adapter

- (void)loadInterstitialAdForParameters:(id<MAAdapterResponseParameters>)parameters andNotify:(id<MAInterstitialAdapterDelegate>)delegate
{
    long long placementId = parameters.thirdPartyAdPlacementIdentifier.longLongValue;
    [self log: @"Loading interstitial ad for placement: %lld...", placementId];
    
    self.interstitialAdDelegate = [[ALInMobiMediationAdapterInterstitialAdDelegate alloc] initWithParentAdapter: self andNotify: delegate];
    self.interstitialAd = [self loadFullscreenAdForPlacementId: placementId
                                                    parameters: parameters
                                                     andNotify: self.interstitialAdDelegate];
}

- (void)showInterstitialAdForParameters:(id<MAAdapterResponseParameters>)parameters andNotify:(id<MAInterstitialAdapterDelegate>)delegate
{
    [self log: @"Showing interstitial ad..."];
    
    BOOL success = [self showFullscreenAd: self.interstitialAd forParameters: parameters];
    if ( !success )
    {
        [self log: @"Interstitial ad not ready"];
        [delegate didFailToDisplayInterstitialAdWithError: [MAAdapterError errorWithAdapterError: MAAdapterError.adDisplayFailedError
                                                                        mediatedNetworkErrorCode: MAAdapterError.adNotReady.code
                                                                     mediatedNetworkErrorMessage: MAAdapterError.adNotReady.message]];
    }
}

#pragma mark - Rewarded Adapter

- (void)loadRewardedAdForParameters:(id<MAAdapterResponseParameters>)parameters andNotify:(id<MARewardedAdapterDelegate>)delegate
{
    long long placementId = parameters.thirdPartyAdPlacementIdentifier.longLongValue;
    [self log: @"Loading rewarded ad for placement: %lld...", placementId];
    
    self.rewardedAdDelegate = [[ALInMobiMediationAdapterRewardedAdDelegate alloc] initWithParentAdapter: self andNotify: delegate];
    self.rewardedAd = [self loadFullscreenAdForPlacementId: placementId
                                                parameters: parameters
                                                 andNotify: self.rewardedAdDelegate];
}

- (void)showRewardedAdForParameters:(id<MAAdapterResponseParameters>)parameters andNotify:(id<MARewardedAdapterDelegate>)delegate
{
    [self log: @"Showing rewarded ad..."];
    
    // Configure reward from server.
    [self configureRewardForParameters: parameters];
    
    BOOL success = [self showFullscreenAd: self.rewardedAd forParameters: parameters];
    if ( !success )
    {
        [self log: @"Rewarded ad not ready"];
        [delegate didFailToDisplayRewardedAdWithError: [MAAdapterError errorWithAdapterError: MAAdapterError.adDisplayFailedError
                                                                    mediatedNetworkErrorCode: MAAdapterError.adNotReady.code
                                                                 mediatedNetworkErrorMessage: MAAdapterError.adNotReady.message]];
    }
}

#pragma mark - Native Adapter

- (void)loadNativeAdForParameters:(id<MAAdapterResponseParameters>)parameters andNotify:(id<MANativeAdAdapterDelegate>)delegate
{
    long long placementId = parameters.thirdPartyAdPlacementIdentifier.longLongValue;
    BOOL isBiddingAd = [parameters.bidResponse al_isValidString];
    
    [self log: @"Loading %@native ad for placement: %lld...", ( isBiddingAd ? @"bidding " : @"" ), placementId];
    
    self.nativeAdDelegate = [[ALInMobiMediationAdapterNativeAdDelegate alloc] initWithParentAdapter: self
                                                                                         parameters: parameters
                                                                                          andNotify: delegate];
    self.nativeAd = [[IMNative alloc] initWithPlacementId: placementId delegate: self.nativeAdDelegate];
    self.nativeAd.extras = [self baseExtras];
    
    [self updatePrivacySettingsWithParameters: parameters];
    
    NSString *bidResponse = parameters.bidResponse;
    if ( [bidResponse al_isValidString] )
    {
        [self.nativeAd load: [bidResponse dataUsingEncoding: NSUTF8StringEncoding]];
    }
    else
    {
        [self.nativeAd load];
    }
}

#pragma mark - Helper Methods

- (IMInterstitial *)loadFullscreenAdForPlacementId:(long long)placementId
                                        parameters:(id<MAAdapterResponseParameters>)parameters
                                         andNotify:(id<IMInterstitialDelegate>)delegate
{
    IMInterstitial *interstitial = [[IMInterstitial alloc] initWithPlacementId: placementId delegate: delegate];
    interstitial.extras = [self baseExtras];
    
    [self updatePrivacySettingsWithParameters: parameters];
    [self updateMuteStateFromServerParameters: parameters.serverParameters];
    
    NSString *bidResponse = parameters.bidResponse;
    if ( [bidResponse al_isValidString] )
    {
        [interstitial load: [bidResponse dataUsingEncoding: NSUTF8StringEncoding]];
    }
    else
    {
        [interstitial load];
    }
    
    return interstitial;
}

- (BOOL)showFullscreenAd:(IMInterstitial *)interstitial forParameters:(id<MAAdapterResponseParameters>)parameters
{
    if ( [interstitial isReady] )
    {
        UIViewController *presentingViewController = parameters.presentingViewController ?: [ALUtils topViewControllerFromKeyWindow];
        [interstitial showFrom: presentingViewController];
        
        return YES;
    }
    else
    {
        return NO;
    }
}

- (NSDictionary<NSString *, id> *)consentDictionaryForParameters:(id<MAAdapterParameters>)parameters
{
    NSMutableDictionary<NSString *, id> *consentDict = [NSMutableDictionary dictionaryWithCapacity: 2];
    
    // Set user consent state. Note: this must be sent as true/false.
    NSNumber *hasUserConsent = [parameters hasUserConsent];
    if ( hasUserConsent != nil )
    {
        consentDict[IMCommonConstants.IM_PARTNER_GDPR_CONSENT_AVAILABLE] = hasUserConsent.boolValue ? @"true" : @"false";
    }
    
    return consentDict;
}

- (NSDictionary<NSString *, id> *)baseExtras
{
    return @{
        @"tp"     : @"c_applovin",
        @"tp-ver" : [ALSdk version]
    };
}

- (NSDictionary<NSString *, id> *)extrasForParameters:(id<MAAdapterParameters>)parameters
                                             adFormat:(MAAdFormat *)adFormat
                              isAdaptiveAdViewEnabled:(BOOL)isAdaptiveAdViewEnabled
{
    NSMutableDictionary<NSString *, id> *extras = [NSMutableDictionary dictionaryWithDictionary: [self baseExtras]];
    
    if ( isAdaptiveAdViewEnabled && [self isAdaptiveAdViewFormat: adFormat forParameters: parameters] )
    {
        CGSize adaptiveSize = [self adaptiveAdSizeFromParameters: parameters];
        extras[AB_AD_SLOT] = [NSString stringWithFormat: @"%dx%d", (int) adaptiveSize.width, (int) adaptiveSize.height];
        extras[AB_TYPE] = [self isInlineAdaptiveAdViewForParameters: parameters] ? ADAPTIVE_TYPE_INLINE : ADAPTIVE_TYPE_ANCHORED;
    }
    
    return extras;
}

- (void)updateMuteStateFromServerParameters:(NSDictionary<NSString *, id> *)serverParameters
{
    if ( [serverParameters al_containsValueForKey: @"is_muted"] )
    {
        [IMSdk setMute: [serverParameters al_numberForKey: @"is_muted"].boolValue];
    }
}

- (void)updatePrivacySettingsWithParameters:(id<MAAdapterParameters>)parameters
{
    [IMSdk setPartnerGDPRConsent: [self consentDictionaryForParameters: parameters]];
    
    NSNumber *isDoNotSell = [parameters isDoNotSell];
    if ( isDoNotSell != nil )
    {
        [IMPrivacyCompliance setDoNotSell: isDoNotSell.boolValue];
    }
}

+ (MAAdapterError *)toMaxError:(IMRequestStatus *)inMobiError
{
    IMStatusCode inMobiErrorCode = inMobiError.code;
    MAAdapterError *adapterError = MAAdapterError.unspecified;
    switch ( inMobiErrorCode )
    {
        case IMStatusCodeNetworkUnReachable:
            adapterError = MAAdapterError.noConnection;
            break;
        case IMStatusCodeNoFill:
            adapterError = MAAdapterError.noFill;
            break;
        case IMStatusCodeSdkNotInitialised:
            adapterError = MAAdapterError.notInitialized;
            break;
        case IMStatusCodeRequestInvalid:
        case IMStatusCodeInvalidBannerframe:
            adapterError = MAAdapterError.badRequest;
            break;
        case IMStatusCodeIncorrectPlacementID:
            adapterError = MAAdapterError.invalidConfiguration;
            break;
        case IMStatusCodeRequestPending:
        case IMStatusCodeMultipleLoadsOnSameInstance:
        case IMStatusCodeAdActive:
        case IMStatusCodeEarlyRefreshRequest:
            adapterError = MAAdapterError.invalidLoadState;
            break;
        case IMStatusCodeRequestTimedOut:
            adapterError = MAAdapterError.timeout;
            break;
        case IMStatusCodeInternalError:
        case IMStatusCodeDroppingNetworkRequest:
        case IMStatusCodeInvalidAudioFrame:
        case IMStatusCodeAudioDisabled:
        case IMStatusCodeAudioDeviceVolumeLow:
            adapterError = MAAdapterError.internalError;
            break;
        case IMStatusCodeServerError:
            adapterError = MAAdapterError.serverError;
            break;
    }
    
    return [MAAdapterError errorWithAdapterError: adapterError
                        mediatedNetworkErrorCode: inMobiErrorCode
                     mediatedNetworkErrorMessage: inMobiError.localizedDescription];
}

- (CGSize)adaptiveAdSizeFromParameters:(id<MAAdapterParameters>)parameters
{
    __block CGFloat adaptiveAdWidth;
    dispatchSyncOnMainQueue(^{
        adaptiveAdWidth = [self adaptiveAdViewWidthFromParameters: parameters];
    });
    
    if ( [self isInlineAdaptiveAdViewForParameters: parameters] )
    {
        CGFloat inlineMaxHeight = [self inlineAdaptiveAdViewMaximumHeightFromParameters: parameters];
        if ( inlineMaxHeight > 0 )
        {
            return CGSizeMake(adaptiveAdWidth, inlineMaxHeight);
        }
        
        CGFloat screenHeight = CGRectGetHeight([UIScreen mainScreen].bounds);
        return CGSizeMake(adaptiveAdWidth, screenHeight);
    }
    
    // Anchored banners use the default adaptive height
    CGFloat anchoredHeight = [MAAdFormat.banner adaptiveSizeForWidth: adaptiveAdWidth].height;
    return CGSizeMake(adaptiveAdWidth, anchoredHeight);
}

- (CGRect)rectFromAdFormat:(MAAdFormat *)adFormat
{
    if ( adFormat == MAAdFormat.banner )
    {
        return CGRectMake(0, 0, 320, 50);
    }
    else if ( adFormat == MAAdFormat.leader )
    {
        return CGRectMake(0, 0, 728, 90);
    }
    else if ( adFormat == MAAdFormat.mrec )
    {
        return CGRectMake(0, 0, 300, 250);
    }
    else
    {
        [NSException raise: NSInvalidArgumentException format: @"Unsupported ad format: %@", adFormat];
        
        return CGRectMake(0, 0, 320, 50);
    }
}

- (NSArray<UIView *> *)clickableViewsForNativeAdView:(MANativeAdView *)maxNativeAdView
{
    // We don't add CTA button here to avoid duplicate click callbacks
    // CTA button is handled by InMobi SDK through registerViewForTracking:
    NSMutableArray *clickableViews = [NSMutableArray array];
    if ( maxNativeAdView.titleLabel )
    {
        [clickableViews addObject: maxNativeAdView.titleLabel];
    }
    if ( maxNativeAdView.advertiserLabel )
    {
        [clickableViews addObject: maxNativeAdView.advertiserLabel];
    }
    if ( maxNativeAdView.bodyLabel )
    {
        [clickableViews addObject: maxNativeAdView.bodyLabel];
    }
    if ( maxNativeAdView.iconImageView )
    {
        [clickableViews addObject: maxNativeAdView.iconImageView];
    }
    if ( maxNativeAdView.mediaContentView )
    {
        [clickableViews addObject: maxNativeAdView.mediaContentView];
    }
    if ( maxNativeAdView.starRatingContentView )
    {
        [clickableViews addObject: maxNativeAdView.starRatingContentView];
    }
    if ( maxNativeAdView.optionsContentView )
    {
        [clickableViews addObject: maxNativeAdView.optionsContentView];
    }
    
    return clickableViews;
}

@end

@implementation ALInMobiMediationAdapterAdViewDelegate

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                               adSize:(CGSize)adSize
                            andNotify:(id<MAAdViewAdapterDelegate>)delegate
{
    self = [super init];
    if ( self )
    {
        self.parentAdapter = parentAdapter;
        self.adSize = adSize;
        self.delegate = delegate;
    }
    return self;
}

- (void)bannerDidFinishLoading:(IMBanner *)banner
{
    [self.parentAdapter log: @"AdView loaded"];
    
    NSMutableDictionary *extraInfo = [NSMutableDictionary dictionaryWithCapacity: 3];
    extraInfo[@"ad_width"] = @((NSInteger) self.adSize.width);
    extraInfo[@"ad_height"] = @((NSInteger) self.adSize.height);
    
    if ( [banner.creativeId al_isValidString] )
    {
        extraInfo[@"creative_id"] = banner.creativeId;
    }
    
    [self.delegate didLoadAdForAdView: banner withExtraInfo: extraInfo];
}

- (void)banner:(IMBanner *)banner didFailToLoadWithError:(IMRequestStatus *)error
{
    MAAdapterError *adapterError = [ALInMobiMediationAdapter toMaxError: error];
    [self.parentAdapter log: @"AdView failed to load with error: %@", adapterError];
    [self.delegate didFailToLoadAdViewAdWithError: adapterError];
}

- (void)bannerAdImpressed:(IMBanner *)banner
{
    [self.parentAdapter log: @"AdView impression tracked"];
    [self.delegate didDisplayAdViewAd];
}

- (void)banner:(IMBanner *)banner didInteractWithParams:(NSDictionary *)params
{
    [self.parentAdapter log: @"AdView clicked"];
    [self.delegate didClickAdViewAd];
}

- (void)bannerDidPresentScreen:(IMBanner *)banner
{
    [self.parentAdapter log: @"AdView expanded"]; // Pretty much StoreKit presented
    [self.delegate didExpandAdViewAd];
}

- (void)bannerDidDismissScreen:(IMBanner *)banner
{
    [self.parentAdapter log: @"AdView collapse"]; // Pretty much StoreKit dismissed
    [self.delegate didCollapseAdViewAd];
}

- (void)userWillLeaveApplicationFromBanner:(IMBanner *)banner
{
    [self.parentAdapter log: @"AdView will leave application"];
}

@end

@implementation ALInMobiMediationAdapterInterstitialAdDelegate

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter andNotify:(id<MAInterstitialAdapterDelegate>)delegate
{
    self = [super init];
    if ( self )
    {
        self.parentAdapter = parentAdapter;
        self.delegate = delegate;
    }
    return self;
}

- (void)interstitial:(IMInterstitial *)interstitial didReceiveWithMetaInfo:(IMAdMetaInfo *)metaInfo
{
    // Assets are not done caching
    [self.parentAdapter log: @"Interstitial request succeeded"];
}

- (void)interstitialDidFinishLoading:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Interstitial loaded"];
    
    if ( [interstitial.creativeId al_isValidString] )
    {
        [self.delegate didLoadInterstitialAdWithExtraInfo: @{@"creative_id" : interstitial.creativeId}];
    }
    else
    {
        [self.delegate didLoadInterstitialAd];
    }
}

- (void)interstitial:(IMInterstitial *)interstitial didFailToLoadWithError:(IMRequestStatus *)error
{
    MAAdapterError *adapterError = [ALInMobiMediationAdapter toMaxError: error];
    [self.parentAdapter log: @"Interstitial failed to load with error: %@", adapterError];
    [self.delegate didFailToLoadInterstitialAdWithError: adapterError];
}

- (void)interstitial:(IMInterstitial *)interstitial didFailToPresentWithError:(IMRequestStatus *)error
{
    [self.parentAdapter log: @"Interstitial failed to display with error: %@", error];
    
    MAAdapterError *adapterError = [MAAdapterError errorWithAdapterError: MAAdapterError.adDisplayFailedError
                                                mediatedNetworkErrorCode: error.code
                                             mediatedNetworkErrorMessage: error.localizedDescription];
    [self.delegate didFailToDisplayInterstitialAdWithError: adapterError];
}

- (void)interstitialWillPresent:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Interstitial will show"];
}

- (void)interstitialDidPresent:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Interstitial did show"];
}

- (void)interstitialAdImpressed:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Interstitial impression tracked"];
    [self.delegate didDisplayInterstitialAd];
}

- (void)interstitial:(IMInterstitial *)interstitial didInteractWithParams:(NSDictionary *)params
{
    [self.parentAdapter log: @"Interstitial clicked"];
    [self.delegate didClickInterstitialAd];
}

- (void)interstitialDidDismiss:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Interstitial hidden"];
    [self.delegate didHideInterstitialAd];
}

- (void)userWillLeaveApplicationFromInterstitial:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Interstitial will leave application"];
}

@end

@implementation ALInMobiMediationAdapterRewardedAdDelegate

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter andNotify:(id<MARewardedAdapterDelegate>)delegate
{
    self = [super init];
    if ( self )
    {
        self.parentAdapter = parentAdapter;
        self.delegate = delegate;
    }
    return self;
}

- (void)interstitial:(IMInterstitial *)interstitial didReceiveWithMetaInfo:(IMAdMetaInfo *)metaInfo
{
    // Assets are not done caching
    [self.parentAdapter log: @"Rewarded ad request succeeded"];
}

- (void)interstitialDidFinishLoading:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Rewarded ad loaded"];
    
    // Passing extra info such as creative id supported in 6.15.0+
    if ( [interstitial.creativeId al_isValidString] )
    {
        [self.delegate didLoadRewardedAdWithExtraInfo: @{@"creative_id" : interstitial.creativeId}];
    }
    else
    {
        [self.delegate didLoadRewardedAd];
    }
}

- (void)interstitial:(IMInterstitial *)interstitial didFailToLoadWithError:(IMRequestStatus *)error
{
    MAAdapterError *adapterError = [ALInMobiMediationAdapter toMaxError: error];
    [self.parentAdapter log: @"Rewarded ad failed to load with error: %@", adapterError];
    [self.delegate didFailToLoadRewardedAdWithError: adapterError];
}

- (void)interstitial:(IMInterstitial *)interstitial didFailToPresentWithError:(IMRequestStatus *)error
{
    [self.parentAdapter log: @"Rewarded ad failed to display with error: %@", error];
    
    MAAdapterError *adapterError = [MAAdapterError errorWithAdapterError: MAAdapterError.adDisplayFailedError
                                                mediatedNetworkErrorCode: error.code
                                             mediatedNetworkErrorMessage: error.localizedDescription];
    [self.delegate didFailToDisplayRewardedAdWithError: adapterError];
}

- (void)interstitialWillPresent:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Rewarded ad will show"];
}

- (void)interstitialDidPresent:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Rewarded ad did show"];
}

- (void)interstitialAdImpressed:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Rewarded ad impression tracked"];
    [self.delegate didDisplayRewardedAd];
}

- (void)interstitial:(IMInterstitial *)interstitial didInteractWithParams:(NSDictionary *)params
{
    [self.parentAdapter log: @"Rewarded ad clicked"];
    [self.delegate didClickRewardedAd];
}

- (void)interstitialDidDismiss:(IMInterstitial *)interstitial
{
    if ( [self hasGrantedReward] || [self.parentAdapter shouldAlwaysRewardUser] )
    {
        MAReward *reward = [self.parentAdapter reward];
        [self.parentAdapter log: @"Rewarded user with reward: %@", reward];
        [self.delegate didRewardUserWithReward: reward];
    }
    
    [self.parentAdapter log: @"Rewarded ad hidden"];
    [self.delegate didHideRewardedAd];
}

- (void)userWillLeaveApplicationFromInterstitial:(IMInterstitial *)interstitial
{
    [self.parentAdapter log: @"Rewarded ad will leave application"];
}

- (void)interstitial:(IMInterstitial *)interstitial rewardActionCompletedWithRewards:(NSDictionary *)rewards
{
    [self.parentAdapter log: @"Rewarded ad granted reward"];
    self.grantedReward = YES;
}

@end

@implementation ALInMobiMediationAdapterNativeAdViewDelegate

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                               format:(MAAdFormat *)format
                           parameters:(id<MAAdapterResponseParameters>)parameters
                            andNotify:(id<MAAdViewAdapterDelegate>)delegate
{
    self = [super init];
    if ( self )
    {
        self.parentAdapter = parentAdapter;
        self.format = format;
        self.serverParameters = parameters.serverParameters;
        self.delegate = delegate;
        self.placementId = parameters.thirdPartyAdPlacementIdentifier;
    }
    return self;
}

- (void)nativeDidFinishLoading:(IMNative *)nativeAd
{
    if ( !nativeAd )
    {
        [self.parentAdapter log: @"Native %@ ad failed to load: no fill", self.format.label];
        [self.delegate didFailToLoadAdViewAdWithError: MAAdapterError.noFill];
        
        return;
    }
    
    [self.parentAdapter log: @"Native %@ ad loaded: %@", self.format.label, self.placementId];
    
    dispatchOnMainQueue(^{
        
        // Need a strong reference of MAInMobiNativeAd in parentAdapter to make gesture recognizers work
        self.parentAdapter.maxNativeAdViewAd = [[MAInMobiNativeAd alloc] initWithParentAdapter: self.parentAdapter
                                                                                      adFormat: self.format
                                                                                  builderBlock:^(MANativeAdBuilder *builder) {
            builder.title = nativeAd.adTitle;
            builder.advertiser = nativeAd.advertiserName;
            builder.body = nativeAd.adDescription;
            builder.callToAction = nativeAd.adCtaText;
            builder.icon = [[MANativeAdImage alloc] initWithImage: nativeAd.adIcon.imageview.image];
            builder.mediaView = [nativeAd getMediaView];
            builder.starRating = @(nativeAd.adRating.doubleValue);
        }];
        
        // Backend will pass down `vertical` as the template to indicate using a vertical native template
        MANativeAdView *maxNativeAdView;
        NSString *templateName = [self.serverParameters al_stringForKey: @"template" defaultValue: @""];
        if ( [templateName containsString: @"vertical"] )
        {
            if ( [templateName isEqualToString: @"vertical"] )
            {
                NSString *verticalTemplateName = ( self.format == MAAdFormat.leader ) ? @"vertical_leader_template" : @"vertical_media_banner_template";
                maxNativeAdView = [MANativeAdView nativeAdViewFromAd: self.parentAdapter.maxNativeAdViewAd withTemplate: verticalTemplateName];
            }
            else
            {
                maxNativeAdView = [MANativeAdView nativeAdViewFromAd: self.parentAdapter.maxNativeAdViewAd withTemplate: templateName];
            }
        }
        else
        {
            maxNativeAdView = [MANativeAdView nativeAdViewFromAd: self.parentAdapter.maxNativeAdViewAd withTemplate: [templateName al_isValidString] ? templateName : @"media_banner_template"];
        }
        
        [self.parentAdapter.maxNativeAdViewAd prepareForInteractionClickableViews: [self.parentAdapter clickableViewsForNativeAdView: maxNativeAdView] withContainer: maxNativeAdView];
        
        if ( [nativeAd.creativeId al_isValidString] )
        {
            NSDictionary *extraInfo = [nativeAd.creativeId al_isValidString] ? @{@"creative_id" : nativeAd.creativeId} : nil;
            [self.delegate didLoadAdForAdView: maxNativeAdView withExtraInfo: extraInfo];
        }
        else
        {
            [self.delegate didLoadAdForAdView: maxNativeAdView];
        }
    });
}

- (void)native:(IMNative *)native didFailToLoadWithError:(IMRequestStatus *)error
{
    MAAdapterError *adapterError = [ALInMobiMediationAdapter toMaxError: error];
    [self.parentAdapter log: @"Native %@ ad failed to load with error: %@", self.format.label, adapterError];
    [self.delegate didFailToLoadAdViewAdWithError: adapterError];
}

- (void)nativeWillPresentScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad will present", self.format.label];
}

- (void)nativeDidPresentScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad did present", self.format.label];
}

- (void)nativeWillDismissScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad will dismiss the screen", self.format.label];
}

- (void)nativeDidDismissScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad did dismiss the screen", self.format.label];
}

- (void)userWillLeaveApplicationFromNative:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad will leave the application", self.format.label];
}

- (void)nativeAdImpressed:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad did show", self.format.label];
    [self.delegate didDisplayAdViewAdWithExtraInfo: nil];
}

- (void)native:(IMNative *)native didInteractWithParams:(NSDictionary *)params
{
    [self.parentAdapter log: @"Native %@ ad clicked", self.format.label];
    [self.delegate didClickAdViewAd];
}

- (void)nativeDidFinishPlayingMedia:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad did finish playing media", self.format.label];
}

- (void)userDidSkipPlayingMediaFromNative:(IMNative *)native
{
    [self.parentAdapter log: @"Native %@ ad user skipped media", self.format.label];
}

- (void)native:(IMNative *)native adAudioStateChanged:(BOOL)audioStateMuted
{
    [self.parentAdapter log: @"Native %@ ad audio state changed", self.format.label];
}

@end

@implementation ALInMobiMediationAdapterNativeAdDelegate

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                           parameters:(id<MAAdapterResponseParameters>)parameters
                            andNotify:(id<MANativeAdAdapterDelegate>)delegate
{
    self = [super init];
    if ( self )
    {
        self.parentAdapter = parentAdapter;
        self.serverParameters = parameters.serverParameters;
        self.delegate = delegate;
        self.placementId = parameters.thirdPartyAdPlacementIdentifier;
    }
    return self;
}

- (void)nativeDidFinishLoading:(IMNative *)nativeAd
{
    if ( !nativeAd )
    {
        [self.parentAdapter log: @"Native ad failed to load: no fill"];
        [self.delegate didFailToLoadNativeAdWithError: MAAdapterError.noFill];
        
        return;
    }
    
    NSString *templateName = [self.serverParameters al_stringForKey: @"template" defaultValue: @""];
    BOOL isTemplateAd = [templateName al_isValidString];
    if ( isTemplateAd && ![nativeAd.adTitle al_isValidString] )
    {
        [self.parentAdapter e: @"Native ad (%@) does not have required assets.", nativeAd];
        [self.delegate didFailToLoadNativeAdWithError: MAAdapterError.missingRequiredNativeAdAssets];
        
        return;
    }
    
    [self.parentAdapter log: @"Native ad loaded: %@", self.placementId];
    
    dispatchOnMainQueue(^{
        
        MANativeAd *maxNativeAd = [[MAInMobiNativeAd alloc] initWithParentAdapter: self.parentAdapter
                                                                         adFormat: MAAdFormat.native
                                                                     builderBlock:^(MANativeAdBuilder *builder) {
            builder.title = nativeAd.adTitle;
            builder.advertiser = nativeAd.advertiserName;
            builder.body = nativeAd.adDescription;
            builder.callToAction = nativeAd.adCtaText;
            builder.icon = [[MANativeAdImage alloc] initWithImage: nativeAd.adIcon.imageview.image];
            builder.mediaView = [nativeAd getMediaView];
            builder.starRating = @(nativeAd.adRating.doubleValue);
        }];
        
        NSDictionary *extraInfo = [nativeAd.creativeId al_isValidString] ? @{@"creative_id" : nativeAd.creativeId} : nil;
        [self.delegate didLoadAdForNativeAd: maxNativeAd withExtraInfo: extraInfo];
    });
}

- (void)native:(IMNative *)native didFailToLoadWithError:(IMRequestStatus *)error
{
    MAAdapterError *adapterError = [ALInMobiMediationAdapter toMaxError: error];
    [self.parentAdapter log: @"Native ad failed to load with error: %@", adapterError];
    [self.delegate didFailToLoadNativeAdWithError: adapterError];
}

- (void)nativeWillPresentScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad will present"];
}

- (void)nativeDidPresentScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad did present"];
}

- (void)nativeWillDismissScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad will dismiss the screen"];
}

- (void)nativeDidDismissScreen:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad did dismiss the screen"];
}

- (void)userWillLeaveApplicationFromNative:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad will leave the application"];
}

- (void)nativeAdImpressed:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad did show"];
    [self.delegate didDisplayNativeAdWithExtraInfo: nil];
}

- (void)native:(IMNative *)native didInteractWithParams:(NSDictionary *)params
{
    [self.parentAdapter log: @"Native ad clicked"];
    [self.delegate didClickNativeAd];
}

- (void)nativeDidFinishPlayingMedia:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad did finish playing media"];
}

- (void)userDidSkipPlayingMediaFromNative:(IMNative *)native
{
    [self.parentAdapter log: @"Native ad user skipped media"];
}

- (void)native:(IMNative *)native adAudioStateChanged:(BOOL)audioStateMuted
{
    [self.parentAdapter log: @"Native ad audio state changed"];
}

@end

@implementation MAInMobiNativeAd

- (instancetype)initWithParentAdapter:(ALInMobiMediationAdapter *)parentAdapter
                             adFormat:(MAAdFormat *)format
                         builderBlock:(NS_NOESCAPE MANativeAdBuilderBlock)builderBlock
{
    self = [super initWithFormat: format builderBlock: builderBlock];
    if ( self )
    {
        self.parentAdapter = parentAdapter;
        self.adFormat = format;
    }
    return self;
}

- (BOOL)prepareForInteractionClickableViews:(NSArray<UIView *> *)clickableViews withContainer:(UIView *)container
{
    IMNative *nativeAd = self.parentAdapter.nativeAd;
    if ( !nativeAd )
    {
        [self.parentAdapter e: @"Failed to register native ad views: native ad is nil."];
        return NO;
    }
    
    // Native integrations
    if ( [container isKindOfClass: [MANativeAdView class]] )
    {
        MANativeAdView *nativeAdView = (MANativeAdView *) container;
        
        // Use new InMobi SDK 11.0.0 API for native ad view registration
        IMNativeViewDataBuilder *builder = [[IMNativeViewDataBuilder alloc] initWithAdParentView: container];
        if ( nativeAdView.titleLabel )
        {
            [builder setTitleView: nativeAdView.titleLabel];
        }
        if ( nativeAdView.advertiserLabel )
        {
            [builder setAdvertiserView: nativeAdView.advertiserLabel];
        }
        if ( nativeAdView.bodyLabel )
        {
            [builder setDescriptionView: nativeAdView.bodyLabel];
        }
        if ( nativeAdView.callToActionButton )
        {
            [builder setCTAView: nativeAdView.callToActionButton];
        }
        if ( nativeAdView.iconImageView )
        {
            [builder setIconView: nativeAdView.iconImageView];
        }
        if ( nativeAdView.starRatingContentView )
        {
            [builder setRatingView: nativeAdView.starRatingContentView];
        }
        
        IMNativeViewData *data = [builder build];
        [nativeAd registerViewForTracking: data];
    }
    // Plugins
    else
    {
        // Use new InMobi SDK 11.0.0 API for native ad view registration
        IMNativeViewDataBuilder *builder = [[IMNativeViewDataBuilder alloc] initWithAdParentView: container];
        
        for ( UIView *view in clickableViews )
        {
            // Find views by tag for plugin integrations
            if ( view.tag == TITLE_LABEL_TAG )
            {
                [builder setTitleView: (UILabel *) view];
            }
            else if ( view.tag == ADVERTISER_VIEW_TAG )
            {
                [builder setAdvertiserView: (UILabel *) view];
            }
            else if ( view.tag == BODY_VIEW_TAG )
            {
                [builder setDescriptionView: (UILabel *) view];
            }
            else if ( view.tag == CALL_TO_ACTION_VIEW_TAG )
            {
                [builder setCTAView: (UIButton *) view];
            }
            else if ( view.tag == ICON_VIEW_TAG )
            {
                [builder setIconView: (UIImageView *) view];
            }
            else if ( view.tag == RATING_VIEW_TAG )
            {
                [builder setRatingView: view];
            }
        }
        
        [nativeAd registerViewForTracking: [builder build]];
    }
    
    return YES;
}

@end
