# Changelog

## 5.4.1.0
* Certified with PubMatic SDK 5.4.1.

## 5.4.0.1
* Fixed adapter versioning for SPM

## 5.4.0.0
* Certified with PubMatic SDK 5.4.0.

## 5.3.0.0
* Certified with PubMatic SDK 5.3.0.

## 5.2.0.0
* Certified with PubMatic SDK 5.2.0.

## 5.1.1.0
* Certified with PubMatic SDK 5.1.1.

## 5.1.0.0
* Certified with PubMatic SDK 5.1.0.

## 5.0.1.0
* Certified with PubMatic SDK 5.0.1.

## 5.0.0.0
* Certified with PubMatic SDK 5.0.0.

## 4.12.0.0
* Certified with PubMatic SDK 4.12.0.

## 4.11.0.0
* Certified with PubMatic SDK 4.11.0.

## 4.10.0.0
* Certified with PubMatic SDK 4.10.0.

## 4.9.0.0
* Certified with PubMatic SDK 4.9.0.

## 4.8.1.0
* Certified with PubMatic SDK 4.8.1.

## 4.8.0.0
* Certified with PubMatic SDK 4.8.0.

## 4.7.0.2
* Distributed as a static framework within the XCFramework.

## 4.7.0.1
* Updated to use PubMatic's new `-loadAdWithResponse:forBiddingHost:` API that includes MAX as the bidding host.

## 4.7.0.0
* Certified with PubMatic SDK 4.7.0.
* Update ad display failed error code.

## 4.6.0.0
* Certified with PubMatic SDK 4.6.0.

## 4.5.2.0
* Certified with PubMatic SDK 4.5.2.

## 4.5.1.0
* Certified with PubMatic SDK 4.5.1.

## 4.5.0.0
* Certified with PubMatic SDK 4.5.0.
* Removed deprecated code paths based on the minimum supported AppLovin MAX SDK version 13.0.0.

## 4.4.0.1
* Updated to support gpid (Global Placement ID).

## 4.4.0.0
* Certified with PubMatic SDK 4.4.0.

## 4.3.0.0
* Certified with PubMatic SDK 4.3.0.

## 4.2.0.1
* Updated to use bidding specific APIs.

## 4.2.0.0
* Certified with PubMatic SDK 4.2.0.
* Removed redundant log output when initialization was already completed.

## 4.1.0.0
* Certified with PubMatic SDK 4.1.0.
* Removed exception throwing if unable to map ad format to that of the network's.

## 4.0.1.0
* Certified with PubMatic SDK 4.0.1.

## 4.0.0.0
* Certified with PubMatic SDK 4.0.0.

## 3.9.0.3
* Unity only: Fix an issue with OpenWrapSDK PodSpec being incorrectly marked as static.

## 3.9.0.2
* Requires minimum AppLovin MAX SDK version be 13.0.0.
* Removed COPPA support.

## 3.9.0.1
* Add support for COPPA.

## 3.9.0.0
* Certified with PubMatic SDK 3.9.0.

## 3.8.0.0
* Certified with PubMatic SDK 3.8.0.
* Changed event mapping for rewarded ad impressions to match other ad types.
* Update ad display failed error code.

## 3.7.0.0
* Initial commit.
* Minimum AppLovin MAX SDK version 12.6.0.
