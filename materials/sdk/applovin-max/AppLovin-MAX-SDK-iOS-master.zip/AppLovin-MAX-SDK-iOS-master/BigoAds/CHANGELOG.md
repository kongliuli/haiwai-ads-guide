# Changelog

## 6.1.0.1
* Added support for SPM.

## 6.1.0.0
* Certified with BigoAds SDK 6.1.0.

## 6.0.0.0
* Certified with BigoAds SDK 6.0.0.

## 5.3.0.0
* Certified with BigoAds SDK 5.3.0.

## 5.2.1.0
* Certified with BigoAds SDK 5.2.1.

## 5.2.0.0
* Certified with BigoAds SDK 5.2.0.

## 5.1.2.0
* Certified with BigoAds SDK 5.1.2.

## 5.1.1.0
* Certified with BigoAds SDK 5.1.1.

## 5.1.0.0
* Certified with BigoAds SDK 5.1.0.

## 5.0.6.0
* Certified with BigoAds SDK 5.0.6.

## 5.0.5.0
* Certified with BigoAds SDK 5.0.5.

## 5.0.0.0
* Certified with BigoAds SDK 5.0.0.

## 4.9.3.0
* Certified with BigoAds SDK 4.9.3.

## 4.9.1.1
* Fixed native ad view clickability issues where only media view and advertiser view were clickable.

## 4.9.1.0
* Certified with BigoAds SDK 4.9.1.

## 4.9.0.0
* Certified with BigoAds SDK 4.9.0.
* Distributed as a static framework within the XCFramework.

## 4.8.1.0
* Certified with BigoAds SDK 4.8.1.

## 4.8.0.0
* Certified with BigoAds SDK 4.8.0.
* Update ad display failed error code.

## 4.7.0.2
* Removed requirement of the title asset for native banners and MRECs.

## 4.7.0.1
* Add support for respecting mute state for native ads.

## 4.7.0.0
* Certified with BigoAds SDK 4.7.0.

## 4.6.0.0
* Certified with BigoAds SDK 4.6.0.
* Removed redundant log output when initialization was already completed.

## 4.5.1.1
* Add support for native ads in external plugins. Requires minimum React Native Plugin 8.0.4 or Flutter Plugin 4.0.2.
* Explicitly fail ad load with code `-5202` if unable to map ad view ad format to that of the network's.

## 4.5.1.0
* Certified with BigoAds SDK 4.5.1.
* Updated the minimum required iOS version to 12.0 in Pod Spec to match BigoAds SDK.
* Remove deprecated native API usages.

## 4.2.3.1
* Fix native ad view ad not triggering callbacks.

## 4.2.3.0
* Certified with BigoAds SDK 4.2.3.
* Updated minimum Xcode requirement to 15.0.

## 4.2.2.0
* Certified with BigoAds SDK 4.2.2.

## 4.2.1.0
* Initial commit.
* Minimum AppLovin MAX SDK version 12.4.1.
